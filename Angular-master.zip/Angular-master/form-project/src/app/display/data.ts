export class Data{
  public name: string;
  public mobile: string;
}
