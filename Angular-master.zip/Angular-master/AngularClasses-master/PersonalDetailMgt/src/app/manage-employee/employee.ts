export class Employee {
    public empId:number;
    public name:string;
    public city:string;
    public mobileNo:string;
    public deptName:string;
}