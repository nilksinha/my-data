export class Inquiry{
    public name:string;
    public mobileNo:string;
    public email:string;
    public course:string;
}
