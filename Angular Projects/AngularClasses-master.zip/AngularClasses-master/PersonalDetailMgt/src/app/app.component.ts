import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  firstName:string = "keyur";
  lastName:string = "Thakor";
  panNo:string = "AMUPT4035A";

  mobileNumber = "7387029671";
  email = "keyurjava27@gmail.com";
  
}
