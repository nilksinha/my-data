import { Employee } from './employee';

export const employeeList:Employee[] = [
    {empId:27,name:'keyur',city:'surat',mobileNo:'73887029671',deptId:10},
    {empId:26,name:'denish',city:'surat',mobileNo:'73887029123',deptId:20},
    {empId:44,name:'vinit',city:'pune',mobileNo:'73887029671',deptId:10}
]

