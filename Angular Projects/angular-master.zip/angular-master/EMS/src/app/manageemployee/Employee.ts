export class Employee {
    empId: number;
    name: string;
    city: string;
    mobileNo: string;
    deptId: number;
}