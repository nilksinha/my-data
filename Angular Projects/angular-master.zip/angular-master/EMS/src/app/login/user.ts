export class User{
    public userName:string;
    public password:string;
    public email:string;
}