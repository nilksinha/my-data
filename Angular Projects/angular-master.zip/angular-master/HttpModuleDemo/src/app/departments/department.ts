export class Department{
    constructor(public id?:number,public deptName?:string){}
}